/* Firebase Messaging SW wrapper - V8. Keep fetch handling out of this file. */
try {
  importScripts('https://www.gstatic.com/firebasejs/10.12.5/firebase-app-compat.js');
  importScripts('https://www.gstatic.com/firebasejs/10.12.5/firebase-messaging-compat.js');

  firebase.initializeApp({
    apiKey: "AIzaSyCq55f9S76tC21mD3Acb99oHg",
    authDomain: "tjfwx-2b9b7.firebaseapp.com",
    projectId: "tjfwx-2b9b7",
    storageBucket: "tjfwx-2b9b7.firebasestorage.app",
    messagingSenderId: "102330026406",
    appId: "1:102330026406:web:f097655edfc36f7af595a2"
  });

  const messaging = firebase.messaging();
  messaging.onBackgroundMessage((payload) => {
    const n = payload.notification || payload.data || {};
    self.registration.showNotification(n.title || 'TJFWeather Alert', {
      body: n.body || 'Weather update',
      icon: './icon-192.png',
      badge: './icon-192.png',
      tag: n.tag || (payload.data && payload.data.tag) || `tjf-${Date.now()}`,
      data: Object.assign({ url: './#radar' }, payload.data || {})
    });
  });
} catch (err) {
  console.error('[TJF V8] firebase-messaging-sw initialization failed', err);
}

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const targetUrl = new URL((event.notification.data && event.notification.data.url) || './#radar', self.location.origin + self.registration.scope).href;
  event.waitUntil((async () => {
    const clientList = await clients.matchAll({ type: 'window', includeUncontrolled: true });
    for (const client of clientList) {
      if ('focus' in client) {
        client.navigate(targetUrl).catch(() => {});
        return client.focus();
      }
    }
    return clients.openWindow(targetUrl);
  })());
});
