# TJFWeather V8 Emergency Fix

This patch fixes two root problems:

1. `sw.js` was intercepting Firestore/Firebase live requests. The new service worker bypasses all third-party/Firebase/Firestore/API fetches and only caches same-origin app-shell files.
2. The prior visual/radar patch was not loading at runtime. This patch injects a visible marker and runtime override script.

## Apply

From the root of the repo in Codespaces:

```bash
unzip /path/to/tjfweather_v8_emergency_fix.zip -d .
python3 apply_tjfweather_v8_emergency_fix.py
```

## Verify before commit

```bash
grep -n "TJF_V8\|FCM_VAPID_PUBLIC_KEY\|tjf_v8_emergency" index.html
grep -n "shouldBypassFetch\|firestore" sw.js
```

## Commit and push

```bash
git add index.html sw.js firebase-messaging-sw.js design_overrides/ apply_tjfweather_v8_emergency_fix.py README_TJF_V8_EMERGENCY_FIX.md
git commit -m "Emergency fix service worker and runtime visual patches"
git push
```

## Verify live site

In the browser console on the live GitHub Pages site:

```js
window.__TJF_V8_INDEX_MARKER
window.__TJF_V8_PATCH_MARKER
window.TJF_FCM_VAPID_PUBLIC_KEY
window.TJF_V8_EMERGENCY_FIX
```

Expected:

```js
"index patched v8"
"TJF V8 EMERGENCY FIX"
"BAivtsZBFQ-lH4pntR3ooI1SEvuuH25UxK8pCnw10vtnQnzfQNkZxHKcaYkJQgS2RcrGIpcO0ULXiBif3Cem6zg"
true
```

If the old service worker is still active, unregister it once from DevTools > Application > Service Workers, or remove/reinstall the mobile Home Screen app.
