/* TJFWeather service worker - V8 emergency safe fetch handler */
const TJF_SW_VERSION = 'tjf-v8-2026-05-16';
const STATIC_CACHE = `tjfweather-static-${TJF_SW_VERSION}`;
const APP_SHELL = [
  './',
  './index.html',
  './manifest.webmanifest',
  './icon-192.png',
  './icon-512.png',
  './design_overrides/tjf_v8_emergency.css',
  './design_overrides/tjf_v8_emergency.js'
];

self.addEventListener('install', (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(STATIC_CACHE).then((cache) =>
      Promise.allSettled(APP_SHELL.map((url) => cache.add(url)))
    )
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((k) => k.startsWith('tjfweather-static-') && k !== STATIC_CACHE).map((k) => caches.delete(k)));
    await self.clients.claim();
  })());
});

function shouldBypassFetch(request) {
  if (!request || request.method !== 'GET') return true;
  const url = new URL(request.url);

  // Never intercept Firebase/Firestore/Google live channels or third-party APIs.
  if (url.origin !== self.location.origin) return true;
  if (/firestore|firebase|googleapis|gstatic|google\.com|identitytoolkit|securetoken/i.test(url.hostname + url.pathname)) return true;
  if (url.pathname.includes('/google.firestore.v1.Firestore/')) return true;

  // Do not cache cache-busted JSON/API data that should remain fresh.
  if (url.pathname.includes('/static/nws_alerts.json')) return true;
  if (url.pathname.includes('/static/spc_day')) return true;
  if (url.pathname.includes('/static/nws/')) return true;
  if (url.pathname.includes('/static/') && url.pathname.endsWith('.json')) return true;

  return false;
}

self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (shouldBypassFetch(request)) return;

  const url = new URL(request.url);
  const isNavigation = request.mode === 'navigate' || (request.headers.get('accept') || '').includes('text/html');

  if (isNavigation) {
    event.respondWith((async () => {
      try {
        const fresh = await fetch(request);
        const cache = await caches.open(STATIC_CACHE);
        cache.put('./index.html', fresh.clone()).catch(() => {});
        return fresh;
      } catch (_) {
        const cached = await caches.match('./index.html');
        return cached || Response.error();
      }
    })());
    return;
  }

  event.respondWith((async () => {
    const cached = await caches.match(request);
    if (cached) return cached;
    const fresh = await fetch(request);
    if (fresh && fresh.ok && url.origin === self.location.origin) {
      const cache = await caches.open(STATIC_CACHE);
      cache.put(request, fresh.clone()).catch(() => {});
    }
    return fresh;
  })());
});

self.addEventListener('push', (event) => {
  let payload = {};
  try { payload = event.data ? event.data.json() : {}; }
  catch (_) { payload = { notification: { title: 'TJFWeather', body: event.data ? event.data.text() : 'Weather update' } }; }

  const n = payload.notification || payload.data || {};
  const title = n.title || payload.title || 'TJFWeather Alert';
  const options = {
    body: n.body || payload.body || 'Weather update',
    icon: './icon-192.png',
    badge: './icon-192.png',
    tag: n.tag || payload.tag || `tjf-${Date.now()}`,
    data: Object.assign({ url: './#radar' }, payload.data || {}, n.data || {}),
    vibrate: [200, 100, 200]
  };
  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const targetUrl = new URL((event.notification.data && event.notification.data.url) || './#radar', self.location.origin + self.registration.scope).href;
  event.waitUntil((async () => {
    const clientList = await clients.matchAll({ type: 'window', includeUncontrolled: true });
    for (const client of clientList) {
      if ('focus' in client) {
        client.navigate(targetUrl).catch(() => {});
        return client.focus();
      }
    }
    return clients.openWindow(targetUrl);
  })());
});
