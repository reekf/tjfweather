#!/usr/bin/env python3
from pathlib import Path
import re
import shutil

ROOT = Path.cwd()
KEY = "BAivtsZBFQ-lH4pntR3ooI1SEvuuH25UxK8pCnw10vtnQnzfQNkZxHKcaYkJQgS2RcrGIpcO0ULXiBif3Cem6zg"

index = ROOT / "index.html"
if not index.exists():
    raise SystemExit("index.html not found. Run this from the root of the tjfweather repo.")

# Backups
for name in ["index.html", "sw.js", "firebase-messaging-sw.js"]:
    p = ROOT / name
    if p.exists():
        b = ROOT / f"{name}.pre-v8.bak"
        if not b.exists():
            shutil.copy2(p, b)

# Copy assets
src_dir = Path(__file__).resolve().parent
if src_dir == ROOT:
    src_dir = ROOT
for rel in ["design_overrides/tjf_v8_emergency.css", "design_overrides/tjf_v8_emergency.js", "sw.js", "firebase-messaging-sw.js"]:
    src = src_dir / rel
    dst = ROOT / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)

html = index.read_text(encoding="utf-8")

# Replace known VAPID key definitions/placeholders.
patterns = [
    r'const\s+FCM_VAPID_PUBLIC_KEY\s*=\s*["\'][^"\']*["\']\s*;',
    r'let\s+FCM_VAPID_PUBLIC_KEY\s*=\s*["\'][^"\']*["\']\s*;',
    r'var\s+FCM_VAPID_PUBLIC_KEY\s*=\s*["\'][^"\']*["\']\s*;',
    r'window\.TJF_FCM_VAPID_PUBLIC_KEY\s*=\s*["\'][^"\']*["\']\s*;',
]
replaced = False
for pat in patterns:
    html, n = re.subn(pat, f'const FCM_VAPID_PUBLIC_KEY = "{KEY}";' if 'FCM_VAPID_PUBLIC_KEY' in pat and 'window' not in pat else f'window.TJF_FCM_VAPID_PUBLIC_KEY = "{KEY}";', html)
    replaced = replaced or bool(n)

if not replaced:
    marker = f'<script>const FCM_VAPID_PUBLIC_KEY = "{KEY}"; window.TJF_FCM_VAPID_PUBLIC_KEY = "{KEY}";</script>\n'
    html = html.replace('</head>', marker + '</head>')
else:
    # Ensure global window copy exists too.
    if 'window.TJF_FCM_VAPID_PUBLIC_KEY' not in html:
        html = html.replace('</head>', f'<script>window.TJF_FCM_VAPID_PUBLIC_KEY = "{KEY}";</script>\n</head>')

# Inject CSS and JS with cache-busting query.
css_tag = '<link rel="stylesheet" href="design_overrides/tjf_v8_emergency.css?v=8">'
js_tag = '<script src="design_overrides/tjf_v8_emergency.js?v=8" defer></script>'
if 'tjf_v8_emergency.css' not in html:
    html = html.replace('</head>', f'    {css_tag}\n</head>')
if 'tjf_v8_emergency.js' not in html:
    html = html.replace('</body>', f'    {js_tag}\n</body>')

# Add obvious runtime marker near head so console checks work even if deferred JS fails.
if '__TJF_V8_INDEX_MARKER' not in html:
    html = html.replace('</head>', '<script>window.__TJF_V8_INDEX_MARKER="index patched v8";</script>\n</head>')

index.write_text(html, encoding="utf-8")

print("TJFWeather V8 emergency fix applied.")
print("Verify with:")
print('  grep -n "TJF_V8\|FCM_VAPID_PUBLIC_KEY\|tjf_v8_emergency" index.html')
print('  grep -n "shouldBypassFetch\|firestore" sw.js')
